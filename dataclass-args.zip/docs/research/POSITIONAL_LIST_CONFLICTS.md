# Positional Arguments + List Parameters: Conflict Analysis

## Problem Statement

**Question:** How do positional arguments interact with list parameters (like `List[str]`)?

**Answer:** They can conflict! Positional lists are **greedy** and create ambiguity.

---

## Test Results Summary

### ✅ SAFE: Optional Lists (with --flags)

```python
@dataclass
class Args:
    input: str = cli_positional()  # Positional
    items: List[str] = cli_short('i')  # Optional list with flag

# CLI: prog input.txt --items a b c
# Result: input='input.txt', items=['a', 'b', 'c']
```

**Why safe:** The `--items` flag prevents ambiguity. Parser knows when list starts.

---

### ✅ SAFE: Positional Scalar(s) + Positional List (at end)

```python
@dataclass
class Args:
    command: str = cli_positional()  # Single positional
    files: List[str] = cli_positional(nargs='+')  # Positional list LAST

# CLI: prog commit file1.txt file2.txt file3.txt
# Result: command='commit', files=['file1.txt', 'file2.txt', 'file3.txt']
```

**Why safe:** First positional takes exactly one value, remainder goes to list.

---

### ⚠️ PROBLEMATIC: Positional List + Other Positionals

```python
@dataclass
class Args:
    files: List[str] = cli_positional(nargs='+')  # List FIRST
    output: str = cli_positional()  # Positional AFTER

# CLI: prog file1.txt file2.txt output.txt
# Question: Which is output? Last one? How does parser know?
# Result: files=['file1.txt', 'file2.txt'], output='output.txt'
```

**Why problematic:** Argparse "guesses" but it's ambiguous and error-prone.

---

### ❌ FATAL: Multiple Positional Lists

```python
@dataclass
class Args:
    inputs: List[str] = cli_positional(nargs='*')
    outputs: List[str] = cli_positional(nargs='*')

# CLI: prog in1.txt in2.txt out1.txt out2.txt
# Result: inputs=['in1.txt', 'in2.txt', 'out1.txt', 'out2.txt'], outputs=[]
```

**Why fatal:** Fundamentally ambiguous. Parser can't know where one list ends and another begins.

---

## Rules & Constraints

### Hard Rules (Must Enforce)

1. **At Most ONE Positional List**
   - Only one field can have `cli_positional(nargs='*')` or `cli_positional(nargs='+')`
   - Multiple positional lists are fundamentally ambiguous

2. **Positional List Must Be LAST**
   - If present, positional list must be the last positional argument
   - Example: `command files...` works, `files... output` doesn't

3. **Optional Lists ALWAYS Use Flags**
   - `List[str]` fields without `cli_positional()` → optional with `--flag`
   - This prevents conflict with positional arguments

---

### Implementation Strategy

#### 1. Validation in `_analyze_config_fields()`

```python
def _analyze_config_fields(self):
    fields_info = {}
    positional_count = 0
    positional_list_count = 0
    last_positional_is_list = False
    
    for field_obj in fields(self.config_class):
        # ... existing analysis ...
        
        if is_cli_positional(field_info):
            positional_count += 1
            
            nargs = get_cli_positional_nargs(field_info)
            if nargs in ('*', '+') or isinstance(nargs, int) and nargs > 1:
                positional_list_count += 1
                last_positional_is_list = True
            else:
                # Scalar positional after list positional
                if positional_list_count > 0:
                    raise ConfigBuilderError(
                        f"Positional list argument must be last. "
                        f"Found scalar positional '{field_obj.name}' after list positional."
                    )
                last_positional_is_list = False
        
        fields_info[field_obj.name] = field_info
    
    # Check for multiple positional lists
    if positional_list_count > 1:
        raise ConfigBuilderError(
            f"Only one positional list argument allowed, found {positional_list_count}. "
            f"Use optional lists with --flags for additional lists."
        )
    
    return fields_info
```

#### 2. Clear Error Messages

**Example 1: Multiple positional lists**
```
ConfigBuilderError: Only one positional list argument allowed, found 2 (fields: 'inputs', 'outputs').
Use optional lists with --flags for additional lists:
  outputs: List[str] = cli_short('o')  # Use --outputs instead
```

**Example 2: Positional list not last**
```
ConfigBuilderError: Positional list argument must be last. 
Found scalar positional 'output' after list positional 'files'.
Consider making 'output' an optional argument:
  output: str = cli_short('o', default='stdout')
```

---

## Decision Matrix

| Pattern | Allowed? | Reason |
|---------|----------|--------|
| `pos1 pos2 --list a b` | ✅ Yes | Optional lists have flags, no ambiguity |
| `pos --list1 a --list2 b` | ✅ Yes | Multiple optional lists OK |
| `command files...` | ✅ Yes | Positional list is last |
| `files... output` | ❌ No | Positional list not last (ambiguous) |
| `inputs... outputs...` | ❌ No | Multiple positional lists (ambiguous) |
| `pos1 pos2 files...` | ✅ Yes | Scalars first, list last |

---

## Example Valid Configurations

### Config 1: Git-style (command + files)
```python
@dataclass
class GitCommit:
    # Required command
    command: str = combine_annotations(
        cli_positional(),
        cli_choices(['commit', 'add', 'rm']),
        cli_help("Git command")
    )
    
    # Variable files (at end)
    files: List[str] = combine_annotations(
        cli_positional(nargs='+'),
        cli_help("Files to process")
    )
    
    # Optional flags
    message: str = cli_short('m', default="")
    verbose: bool = cli_short('v', default=False)

# Usage: prog commit file1.py file2.py -m "Message" -v
```

### Config 2: Copy-style (source + dest)
```python
@dataclass
class Copy:
    # Two required positionals
    source: str = cli_positional(help="Source file")
    dest: str = cli_positional(help="Destination file")
    
    # Optional list with flag
    exclude: List[str] = cli_short('e', default_factory=list)
    
    # Optional flags
    recursive: bool = cli_short('r', default=False)

# Usage: prog source.txt dest.txt -e *.tmp -e *.log -r
```

### Config 3: Converter (input + optional output)
```python
@dataclass
class Convert:
    # Required positional
    input: str = cli_positional(help="Input file")
    
    # Optional positional (nargs='?')
    output: str = cli_positional(nargs='?', default='stdout', help="Output file")
    
    # Optional list with flag
    plugins: List[str] = cli_short('p', default_factory=list)
    
    # Optional flag
    format: str = cli_short('f', default='json')

# Usage: prog input.txt output.txt -f yaml
# Usage: prog input.txt -f yaml  # Uses stdout
```

---

## Example INVALID Configurations

### ❌ Invalid 1: Multiple positional lists

```python
@dataclass
class Invalid:
    inputs: List[str] = cli_positional(nargs='+')
    outputs: List[str] = cli_positional(nargs='+')  # ERROR!

# ConfigBuilderError: Only one positional list argument allowed
```

**Fix:**
```python
@dataclass
class Fixed:
    inputs: List[str] = cli_positional(nargs='+')
    outputs: List[str] = cli_short('o')  # Use optional list with flag
```

---

### ❌ Invalid 2: Positional list not last

```python
@dataclass
class Invalid:
    files: List[str] = cli_positional(nargs='+')
    output: str = cli_positional()  # ERROR!

# ConfigBuilderError: Positional list argument must be last
```

**Fix Option 1:** Make output optional
```python
@dataclass
class Fixed1:
    files: List[str] = cli_positional(nargs='+')
    output: str = cli_short('o', default='stdout')
```

**Fix Option 2:** Use exact count
```python
@dataclass
class Fixed2:
    # If you know there are exactly 2 files
    files: List[str] = cli_positional(nargs=2, help="Input and output files")

# CLI: prog input.txt output.txt
# files=['input.txt', 'output.txt']
```

**Fix Option 3:** Swap order (if semantically valid)
```python
@dataclass
class Fixed3:
    output: str = cli_positional()
    files: List[str] = cli_positional(nargs='+')

# CLI: prog output.txt file1.txt file2.txt
```

---

## Documentation Plan

### README Section

```markdown
### ⚠️ Positional List Constraints

Positional arguments with variable length (nargs='*' or '+') have restrictions:

**Rules:**
1. At most ONE positional list per CLI
2. Positional list must be the LAST positional argument
3. For multiple lists, use optional lists with flags

**Valid:**
\```python
@dataclass
class GitCommit:
    command: str = cli_positional()  # First
    files: List[str] = cli_positional(nargs='+')  # Last (OK!)
    exclude: List[str] = cli_short('e', default_factory=list)  # Optional list (OK!)
\```

**Invalid:**
\```python
@dataclass
class Invalid:
    files: List[str] = cli_positional(nargs='+')
    output: str = cli_positional()  # ERROR: positional after list
\```

**Why?** Positional lists are greedy and create ambiguity. The parser can't determine 
where one positional list ends and another begins without flags.
```

---

## Testing Plan

### Test Cases for Validation

```python
def test_multiple_positional_lists_error():
    """Should raise error for multiple positional lists."""
    @dataclass
    class Invalid:
        inputs: List[str] = cli_positional(nargs='+')
        outputs: List[str] = cli_positional(nargs='+')
    
    with pytest.raises(ConfigBuilderError, match="Only one positional list"):
        build_config(Invalid, args=[])

def test_positional_list_not_last_error():
    """Should raise error when positional list is not last."""
    @dataclass
    class Invalid:
        files: List[str] = cli_positional(nargs='+')
        output: str = cli_positional()
    
    with pytest.raises(ConfigBuilderError, match="must be last"):
        build_config(Invalid, args=[])

def test_positional_list_last_valid():
    """Should allow positional list when it's last."""
    @dataclass
    class Valid:
        command: str = cli_positional()
        files: List[str] = cli_positional(nargs='+')
    
    config = build_config(Valid, args=['commit', 'f1.txt', 'f2.txt'])
    assert config.command == 'commit'
    assert config.files == ['f1.txt', 'f2.txt']

def test_multiple_optional_lists_valid():
    """Should allow multiple optional lists (with flags)."""
    @dataclass
    class Valid:
        input: str = cli_positional()
        list1: List[str] = cli_short('a')
        list2: List[str] = cli_short('b')
    
    config = build_config(Valid, args=[
        'input.txt', 
        '--list1', 'a1', 'a2',
        '--list2', 'b1', 'b2'
    ])
    assert config.input == 'input.txt'
    assert config.list1 == ['a1', 'a2']
    assert config.list2 == ['b1', 'b2']

def test_positional_exact_count_with_scalar():
    """Should allow positional with exact count + scalar after."""
    @dataclass
    class Valid:
        # Exact count (not a greedy list)
        coords: List[float] = cli_positional(nargs=2, metavar='X Y')
        label: str = cli_positional()
    
    config = build_config(Valid, args=['1.5', '2.5', 'PointA'])
    assert config.coords == [1.5, 2.5]
    assert config.label == 'PointA'
```

---

## Summary & Recommendations

### Key Takeaways

1. **Optional Lists Are Safe**
   - Use `--flag` for lists → no ambiguity
   - Can have as many as needed

2. **Positional Lists Are Constrained**
   - Maximum ONE per CLI
   - Must be LAST positional
   - Use with caution

3. **Validation Is Critical**
   - Detect conflicts at builder initialization
   - Provide clear error messages
   - Guide users to fix

4. **Most Common Patterns Work**
   - Git-style: `command files...`
   - Copy-style: `source dest --extras...`
   - Convert-style: `input [output] --options...`

### Implementation Checklist

- [ ] Add validation in `_analyze_config_fields()`
- [ ] Detect multiple positional lists → error
- [ ] Detect positional list not last → error
- [ ] Provide helpful error messages with fixes
- [ ] Add comprehensive test cases (10+)
- [ ] Document constraints in README
- [ ] Add examples showing valid patterns
- [ ] Add examples showing invalid patterns + fixes

### Error Message Quality

Good error messages should:
1. Clearly state what's wrong
2. Explain why it's a problem
3. Suggest a fix

**Example:**
```
ConfigBuilderError: Positional list argument must be last positional.

Problem: Found positional 'output' after positional list 'files'.

Why: Positional lists are greedy and consume all remaining values.
     The parser can't determine where 'files' ends and 'output' begins.

Fix: Use an optional argument with a flag instead:
     output: str = cli_short('o', default='stdout')

Or: Swap the order if semantically valid:
     output: str = cli_positional()  # First
     files: List[str] = cli_positional(nargs='+')  # Last
```

---

**Great question! This research will prevent user confusion and ensure robust implementation.** 🎯

*Analysis Date: October 31, 2024*
