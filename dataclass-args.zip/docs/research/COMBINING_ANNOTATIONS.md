# Combining Annotations: Short Form + Enum/Choices

How to use multiple annotations on the same field.

---

## Problem: Multiple Annotations on Same Field

You want a field that has:
- Short option (`-l`)
- Long option (`--log-level`)
- Restricted values (Enum or choices)

---

## Solution 1: Using Enum Type (Recommended)

**The Enum type itself provides the restrictions, so you only need `cli_short()`:**

```python
from dataclasses import dataclass
from enum import Enum
from dataclass_args import build_config, cli_short

class LogLevel(Enum):
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"

@dataclass
class Config:
    # Enum type provides restrictions, cli_short() provides short option
    log_level: LogLevel = cli_short('l', default=LogLevel.INFO)
    environment: Environment = cli_short('e', default=Environment.DEV)
    output_format: OutputFormat = cli_short('o', default=OutputFormat.JSON)

# Usage:
config = build_config(Config, ['-l', 'debug', '-e', 'prod', '-o', 'yaml'])
config = build_config(Config, ['--log-level', 'debug'])  # Long form still works

# Invalid catches error:
config = build_config(Config, ['-l', 'invalid'])
# Error: Invalid choice: 'invalid' (choose from: debug, info, warning, error)
```

**How it works:**
1. The type annotation (`LogLevel`) tells the builder to restrict values
2. The `cli_short('l')` adds the short option
3. The builder automatically detects Enum and creates restrictions

---

## Solution 2: Extending cli_short() to Accept Metadata

**If we extend `cli_short()` to merge with existing metadata:**

```python
def cli_short(short: str, **kwargs) -> Any:
    """
    Add short-form option for a CLI argument.
    Can be combined with other annotations.

    Args:
        short: Single character for short option (e.g., 'n' for -n)
        **kwargs: Additional field parameters (including other annotations)

    Example:
        # Combines short option with choices
        level: str = cli_short('l', cli_choices(['low', 'med', 'high']))
    """
    if len(short) != 1:
        raise ValueError(f"Short option must be single character, got: {short}")

    field_kwargs = kwargs.copy()
    metadata = field_kwargs.pop("metadata", {})

    # If an annotation was passed, extract its metadata
    for key, value in list(field_kwargs.items()):
        if hasattr(value, 'metadata'):
            # This is another annotation, merge its metadata
            metadata.update(value.metadata)
            field_kwargs.pop(key)

    metadata["cli_short"] = short
    field_kwargs["metadata"] = metadata
    return field(**field_kwargs)
```

**Usage with cli_choices():**

```python
@dataclass
class Config:
    # Short option + custom choices
    region: str = cli_short('r', cli_choices(['us-east', 'us-west', 'eu-west']))

    # Short option + help text + choices
    size: str = cli_short('s',
        cli_choices(['small', 'medium', 'large']),
        cli_help("Instance size"),
        default='medium'
    )

# Usage:
config = build_config(Config, ['-r', 'us-west', '-s', 'large'])
```

---

## Solution 3: Using field() with Combined Metadata (Current Best Practice)

**Manually combine metadata using `field()`:**

```python
from dataclasses import dataclass, field
from dataclass_args import build_config

@dataclass
class Config:
    # Combine short option + choices in metadata
    region: str = field(
        default='us-east',
        metadata={
            'cli_short': 'r',
            'cli_choices': ['us-east', 'us-west', 'eu-west'],
            'cli_help': 'AWS region'
        }
    )

    # Short option with Enum (no cli_choices needed)
    log_level: LogLevel = field(
        default=LogLevel.INFO,
        metadata={
            'cli_short': 'l',
            'cli_help': 'Logging level'
        }
    )

# Usage:
config = build_config(Config, ['-r', 'us-west', '-l', 'debug'])
```

---

## Solution 4: Using combine_annotations() Helper

**Create a helper to cleanly combine multiple annotations:**

```python
def combine_annotations(*annotations, **field_kwargs) -> Any:
    """
    Combine multiple CLI annotations into a single field.

    Args:
        *annotations: Annotation results to combine
        **field_kwargs: Additional field parameters

    Returns:
        Field object with combined metadata

    Example:
        @dataclass
        class Config:
            region: str = combine_annotations(
                cli_short('r'),
                cli_choices(['us-east', 'us-west', 'eu-west']),
                cli_help("AWS region"),
                default='us-east'
            )
    """
    combined_metadata = {}

    # Extract metadata from each annotation
    for annotation in annotations:
        if hasattr(annotation, 'metadata') and annotation.metadata:
            combined_metadata.update(annotation.metadata)

    # Merge with any existing metadata in kwargs
    existing_metadata = field_kwargs.pop("metadata", {})
    combined_metadata.update(existing_metadata)

    field_kwargs["metadata"] = combined_metadata
    return field(**field_kwargs)
```

**Usage:**

```python
from dataclass_args import build_config, cli_short, cli_choices, cli_help, combine_annotations

@dataclass
class Config:
    # Combine short, choices, and help
    region: str = combine_annotations(
        cli_short('r'),
        cli_choices(['us-east', 'us-west', 'eu-west']),
        cli_help("AWS region"),
        default='us-east'
    )

    # Short + help for enum (no choices needed - Enum type provides that)
    log_level: LogLevel = combine_annotations(
        cli_short('l'),
        cli_help("Logging level"),
        default=LogLevel.INFO
    )

    # Short + file loadable + help
    config_file: str = combine_annotations(
        cli_short('c'),
        cli_file_loadable(),
        cli_help("Configuration file path"),
        default="config.yaml"
    )

# Usage:
config = build_config(Config, [
    '-r', 'us-west',           # Short form with restricted choice
    '-l', 'debug',             # Short form with enum
    '-c', '@config.yaml'       # Short form with file loading
])
```

---

## Comparison of Approaches

### Approach 1: Enum Type (Simplest)
```python
log_level: LogLevel = cli_short('l', default=LogLevel.INFO)
```
✅ Clean, type-safe
✅ No extra syntax needed
❌ Only works with Enums (not custom string choices)

### Approach 2: Extended cli_short()
```python
region: str = cli_short('r', cli_choices(['us-east', 'us-west']))
```
✅ Readable, annotation-style
❌ Requires cli_short() to intelligently parse kwargs
❌ Order might matter

### Approach 3: Manual field()
```python
region: str = field(
    default='us-east',
    metadata={'cli_short': 'r', 'cli_choices': ['us-east', 'us-west']}
)
```
✅ Explicit, always works
✅ Most flexible
❌ More verbose
❌ Less discoverable

### Approach 4: combine_annotations()
```python
region: str = combine_annotations(
    cli_short('r'),
    cli_choices(['us-east', 'us-west']),
    cli_help("AWS region"),
    default='us-east'
)
```
✅ Clean composition
✅ Order-independent
✅ Discoverable
❌ Extra helper function needed

---

## Recommended Implementation

**Use a hybrid approach:**

### 1. For Enum fields → Just cli_short()
```python
class LogLevel(Enum):
    DEBUG = "debug"
    INFO = "info"

@dataclass
class Config:
    # Type annotation provides restrictions
    log_level: LogLevel = cli_short('l', default=LogLevel.INFO)
```

### 2. For custom choices → combine_annotations()
```python
@dataclass
class Config:
    region: str = combine_annotations(
        cli_short('r'),
        cli_choices(['us-east', 'us-west']),
        default='us-east'
    )
```

### 3. For complex combinations → combine_annotations()
```python
@dataclass
class Config:
    system_prompt: str = combine_annotations(
        cli_short('s'),
        cli_file_loadable(),
        cli_help("System prompt (supports @file.txt)"),
        default="You are a helpful assistant"
    )
```

---

## Complete Real-World Example

```python
from dataclasses import dataclass
from enum import Enum
from dataclass_args import (
    build_config,
    cli_short,
    cli_choices,
    cli_help,
    cli_file_loadable,
    combine_annotations
)

class LogLevel(Enum):
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"

class OutputFormat(Enum):
    JSON = "json"
    YAML = "yaml"
    TEXT = "text"

@dataclass
class AppConfig:
    # Simple: short + default
    name: str = cli_short('n')
    port: int = cli_short('p', default=8080)

    # Enum: short + type restriction
    log_level: LogLevel = cli_short('l', default=LogLevel.INFO)
    output: OutputFormat = cli_short('o', default=OutputFormat.JSON)

    # Custom choices: short + explicit choices
    region: str = combine_annotations(
        cli_short('r'),
        cli_choices(['us-east', 'us-west', 'eu-west', 'ap-south']),
        cli_help("Deployment region"),
        default='us-east'
    )

    # Complex: short + file loadable + help
    system_prompt: str = combine_annotations(
        cli_short('s'),
        cli_file_loadable(),
        cli_help("System prompt text (supports @file.txt)"),
        default="You are a helpful assistant"
    )

    # Flags
    debug: bool = cli_short('d', default=False)
    verbose: bool = cli_short('v', default=False)

# Usage examples:
config = build_config(AppConfig, [
    '-n', 'myapp',
    '-p', '9000',
    '-l', 'debug',              # Enum: validated
    '-o', 'yaml',               # Enum: validated
    '-r', 'us-west',            # Choices: validated
    '-s', '@prompts/sys.txt',   # File loadable with short form
    '-d',                       # Boolean flag (store_true)
    '-v'                        # Boolean flag (store_true)
])

# Help output:
# ./app.py --help
#
# Options:
#   -n, --name NAME              (required)
#   -p, --port PORT              (default: 8080)
#   -l, --log-level {debug,info,warning,error}
#                                (default: info)
#   -o, --output {json,yaml,text}
#                                (default: json)
#   -r, --region {us-east,us-west,eu-west,ap-south}
#                                Deployment region (default: us-east)
#   -s, --system-prompt PROMPT   System prompt text (supports @file.txt)
#   -d, --debug                  (default: False)
#   --no-debug                   Disable debug
#   -v, --verbose                (default: False)
#   --no-verbose                 Disable verbose
```

---

## Implementation Notes

1. **Type checking works best with Enum** - mypy/type checkers understand `LogLevel` type
2. **cli_choices() is runtime only** - no static type checking for string choices
3. **combine_annotations()** should be implemented in `annotations.py` to merge metadata
4. All approaches are backward compatible - existing code continues to work

---

## Recommendation

**Implement `combine_annotations()` helper** in `annotations.py`:
- Clean composition of multiple annotations
- Order-independent
- Works with all annotation types
- Easy to extend in future

This gives users maximum flexibility with clean syntax.
