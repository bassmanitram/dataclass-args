# Feature Usage Examples

Practical examples showing how users would use the three proposed features.

---

## Feature 1: Short-Form Options

### Basic Usage

```python
from dataclasses import dataclass
from dataclass_args import build_config, cli_short, cli_help

@dataclass
class AppConfig:
    name: str = cli_short('n', cli_help("Application name"))
    host: str = cli_short('h', default="localhost")
    port: int = cli_short('p', default=8080)
    verbose: bool = cli_short('v', default=False)
```

**Command Line Usage:**

```bash
# Short form
./myapp.py -n MyApp -h 0.0.0.0 -p 9000 -v true

# Long form (still works)
./myapp.py --name MyApp --host 0.0.0.0 --port 9000 --verbose true

# Mixed (best of both)
./myapp.py -n MyApp --host 0.0.0.0 -p 9000 --verbose true

# Help shows both forms
./myapp.py --help
# Options:
#   -n, --name NAME        Application name
#   -h, --host HOST        (default: localhost)
#   -p, --port PORT        (default: 8080)
#   -v, --verbose VERBOSE  (default: False)
```

### Real-World Example: Database Tool

```python
from dataclasses import dataclass
from dataclass_args import build_config, cli_short, cli_help

@dataclass
class DatabaseConfig:
    # Connection
    host: str = cli_short('h', cli_help("Database host"))
    port: int = cli_short('p', cli_help("Database port"), default=5432)
    database: str = cli_short('d', cli_help("Database name"))
    username: str = cli_short('u', cli_help("Username"))
    password: str = cli_short('w', cli_help("Password"))  # 'w' for passWord

    # Options
    timeout: int = cli_short('t', default=30)
    ssl: bool = cli_short('s', default=False)
    verbose: bool = cli_short('v', default=False)

# Usage becomes very concise:
# ./db-tool.py -h localhost -p 5432 -d mydb -u admin -w secret -s true -v true

# vs the long form:
# ./db-tool.py --host localhost --port 5432 --database mydb --username admin --password secret --ssl true --verbose true
```

---

## Feature 2: Negative Flag Options

### Basic Usage

```python
from dataclasses import dataclass
from dataclass_args import build_config

@dataclass
class BuildConfig:
    # Boolean flags with defaults
    debug: bool = False
    optimize: bool = True
    cache: bool = True
    tests: bool = True
    docs: bool = False
```

**Command Line Usage:**

```bash
# Enable flags (default False)
./build.py --debug --docs
# Result: debug=True, docs=True

# Disable flags (default True)
./build.py --no-optimize --no-tests
# Result: optimize=False, tests=False

# Mixed usage
./build.py --debug --no-cache
# Result: debug=True, cache=False

# Explicit clarity
./build.py --no-debug --no-optimize --no-cache --no-tests --no-docs
# Result: All False

# Help shows both forms
./build.py --help
# Options:
#   --debug              Enable debug mode (default: False)
#   --no-debug           Disable debug mode
#   --optimize           Optimization enabled (default: True)
#   --no-optimize        Disable optimization
```

### Real-World Example: CI/CD Pipeline

```python
from dataclasses import dataclass
from dataclass_args import build_config, cli_help

@dataclass
class PipelineConfig:
    # Build options (usually enabled)
    build: bool = cli_help("Build the project", default=True)
    test: bool = cli_help("Run tests", default=True)
    lint: bool = cli_help("Run linting", default=True)
    security_scan: bool = cli_help("Run security scan", default=True)

    # Optional steps (usually disabled)
    deploy: bool = cli_help("Deploy to environment", default=False)
    notify: bool = cli_help("Send notifications", default=False)
    benchmark: bool = cli_help("Run benchmarks", default=False)

# Quick CI build without slow steps:
# ./pipeline.py --no-security-scan --no-lint

# Full pipeline with deployment:
# ./pipeline.py --deploy --notify

# Skip everything except tests:
# ./pipeline.py --no-build --no-lint --no-security-scan

# Development mode: skip tests but deploy locally:
# ./pipeline.py --no-test --deploy
```

### Real-World Example: Feature Flags

```python
from dataclasses import dataclass
from dataclass_args import build_config, cli_short

@dataclass
class ServerConfig:
    # Feature flags
    api_v2: bool = True
    new_ui: bool = True
    analytics: bool = True
    auth_2fa: bool = False
    beta_features: bool = False

    # Service options
    name: str = cli_short('n')
    port: int = cli_short('p', default=8000)

# Disable problematic new UI in production:
# ./server.py -n prod-1 -p 8000 --no-new-ui

# Enable beta features for staging:
# ./server.py -n staging-1 --beta-features --auth-2fa

# Minimal mode (disable optional features):
# ./server.py -n minimal --no-analytics --no-auth-2fa
```

---

## Feature 3: Restricted Value Options (Enum)

### Basic Usage with Enum

```python
from dataclasses import dataclass
from enum import Enum
from dataclass_args import build_config

class LogLevel(Enum):
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"

class Environment(Enum):
    DEV = "development"
    STAGING = "staging"
    PROD = "production"

@dataclass
class AppConfig:
    log_level: LogLevel = LogLevel.INFO
    environment: Environment = Environment.DEV
    name: str = "myapp"
```

**Command Line Usage:**

```bash
# Set log level (case insensitive)
./app.py --log-level debug
./app.py --log-level DEBUG
./app.py --log-level DeBuG

# Set environment
./app.py --environment prod
./app.py --environment PRODUCTION

# Invalid value shows error with choices
./app.py --log-level verbose
# Error: Invalid choice: 'verbose' (choose from: debug, info, warning, error, critical)

# Help shows available choices
./app.py --help
# Options:
#   --log-level {debug,info,warning,error,critical}
#                         (default: info)
#   --environment {dev,staging,prod}
#                         (default: dev)
```

### Alternative: Custom Choices Annotation

```python
from dataclasses import dataclass
from dataclass_args import build_config, cli_choices, cli_help

@dataclass
class ServerConfig:
    # AWS regions
    region: str = cli_choices(
        ['us-east-1', 'us-west-2', 'eu-west-1', 'ap-southeast-1'],
        cli_help("AWS region"),
        default='us-east-1'
    )

    # Instance sizes
    instance_size: str = cli_choices(
        ['small', 'medium', 'large', 'xlarge'],
        default='medium'
    )

    # Database engine
    db_engine: str = cli_choices(
        ['postgres', 'mysql', 'mongodb'],
        default='postgres'
    )

# Usage:
# ./deploy.py --region us-west-2 --instance-size xlarge --db-engine mysql

# Invalid choice shows error:
# ./deploy.py --region invalid
# Error: Invalid choice: 'invalid' (choose from: us-east-1, us-west-2, eu-west-1, ap-southeast-1)
```

### Real-World Example: Cloud Deployment Tool

```python
from dataclasses import dataclass
from enum import Enum
from dataclass_args import build_config, cli_short, cli_help, cli_choices

class CloudProvider(Enum):
    AWS = "aws"
    AZURE = "azure"
    GCP = "gcp"

class InstanceSize(Enum):
    SMALL = "small"
    MEDIUM = "medium"
    LARGE = "large"
    XLARGE = "xlarge"

class Environment(Enum):
    DEV = "development"
    STAGING = "staging"
    PROD = "production"

@dataclass
class DeploymentConfig:
    # Required
    name: str = cli_short('n', cli_help("Deployment name"))

    # Enums for validated choices
    provider: CloudProvider = CloudProvider.AWS
    size: InstanceSize = InstanceSize.MEDIUM
    environment: Environment = Environment.DEV

    # Custom choices for provider-specific values
    region: str = cli_choices(
        ['us-east-1', 'us-west-2', 'eu-west-1', 'ap-southeast-1'],
        default='us-east-1'
    )

    # Flags
    auto_scale: bool = True
    monitoring: bool = True

# Usage examples:

# Basic deployment:
# ./deploy.py -n myapp --environment prod

# Custom configuration:
# ./deploy.py -n myapp --provider gcp --size xlarge --region us-west-2 --environment prod

# Cost-saving dev deployment:
# ./deploy.py -n myapp-dev --size small --no-monitoring --no-auto-scale

# Help shows all valid choices:
# ./deploy.py --help
# Options:
#   -n, --name NAME       Deployment name
#   --provider {aws,azure,gcp}
#                         (default: aws)
#   --size {small,medium,large,xlarge}
#                         (default: medium)
#   --environment {dev,staging,prod}
#                         (default: dev)
#   --region {us-east-1,us-west-2,eu-west-1,ap-southeast-1}
#                         (default: us-east-1)
#   --auto-scale         Auto scaling enabled (default: True)
#   --no-auto-scale      Disable auto scaling
```

---

## Combined Example: Complete CLI Application

```python
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional
from dataclass_args import build_config, cli_short, cli_help, cli_choices, cli_exclude

class LogLevel(Enum):
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"

class OutputFormat(Enum):
    JSON = "json"
    YAML = "yaml"
    TABLE = "table"

@dataclass
class AppConfig:
    # Required with short form
    name: str = cli_short('n', cli_help("Application name"))

    # Optional with short form and default
    host: str = cli_short('h', cli_help("Server host"), default="0.0.0.0")
    port: int = cli_short('p', cli_help("Server port"), default=8080)

    # Enum for validated choices
    log_level: LogLevel = cli_short('l', default=LogLevel.INFO)
    output_format: OutputFormat = cli_short('o', default=OutputFormat.JSON)

    # Custom choices
    region: str = cli_choices(
        ['us-east', 'us-west', 'eu-west', 'ap-south'],
        default='us-east'
    )

    # Flags with negative forms
    debug: bool = cli_short('d', default=False)
    verbose: bool = cli_short('v', default=False)
    quiet: bool = cli_short('q', default=False)
    enable_cache: bool = True
    enable_metrics: bool = True

    # Lists (can specify multiple times)
    allowed_origins: List[str] = cli_help("CORS allowed origins", default_factory=list)

    # Hidden from CLI
    _internal_id: str = cli_exclude(default="auto-generated")

def main():
    config = build_config(AppConfig)

    if not config.quiet:
        print(f"Starting {config.name}")
        print(f"Server: {config.host}:{config.port}")
        print(f"Log Level: {config.log_level.value}")
        print(f"Region: {config.region}")

    if config.debug:
        print(f"[DEBUG] Full config: {config}")

if __name__ == "__main__":
    main()
```

**Usage Examples:**

```bash
# Minimal (using many defaults):
./app.py -n myapp

# Common development setup:
./app.py -n myapp -d -v --log-level debug

# Production deployment:
./app.py -n prod-api -h 0.0.0.0 -p 443 --log-level warning --region us-west --no-debug

# Custom format and region:
./app.py -n myapp -o yaml --region eu-west

# Disable cache and metrics:
./app.py -n myapp --no-enable-cache --no-enable-metrics

# Quiet mode:
./app.py -n myapp -q

# Multiple CORS origins:
./app.py -n myapp --allowed-origins https://example.com --allowed-origins https://app.com

# Complex real-world example:
./app.py \
  -n prod-api-1 \
  -h 0.0.0.0 \
  -p 8443 \
  --log-level warning \
  --output-format json \
  --region us-west \
  --no-debug \
  --no-verbose \
  --enable-cache \
  --enable-metrics \
  --allowed-origins https://api.example.com \
  --allowed-origins https://app.example.com

# Same thing with more short options:
./app.py -n prod-api-1 -h 0.0.0.0 -p 8443 -l warning -o json --region us-west

# Help shows everything:
./app.py --help
# Options:
#   -n, --name NAME              Application name (required)
#   -h, --host HOST              Server host (default: 0.0.0.0)
#   -p, --port PORT              Server port (default: 8080)
#   -l, --log-level {debug,info,warning,error}
#                                (default: info)
#   -o, --output-format {json,yaml,table}
#                                (default: json)
#   --region {us-east,us-west,eu-west,ap-south}
#                                (default: us-east)
#   -d, --debug                  (default: False)
#   --no-debug                   Disable debug
#   -v, --verbose                (default: False)
#   --no-verbose                 Disable verbose
#   -q, --quiet                  (default: False)
#   --no-quiet                   Disable quiet
#   --enable-cache               (default: True)
#   --no-enable-cache            Disable cache
#   --enable-metrics             (default: True)
#   --no-enable-metrics          Disable metrics
#   --allowed-origins            CORS allowed origins (can be specified multiple times)
```

---

## Migration Example: Before and After

### Before (Current):

```python
@dataclass
class Config:
    name: str
    host: str = "localhost"
    port: int = 8080
    debug: bool = False
    log_level: str = "info"

# Usage - verbose and error-prone:
./app.py --name myapp --host 0.0.0.0 --port 9000 --debug true --log-level debug

# Invalid log level silently accepted:
./app.py --name myapp --log-level VERBOSE  # No error, just wrong
```

### After (With New Features):

```python
from enum import Enum

class LogLevel(Enum):
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"

@dataclass
class Config:
    name: str = cli_short('n')
    host: str = cli_short('h', default="localhost")
    port: int = cli_short('p', default=8080)
    debug: bool = False
    log_level: LogLevel = LogLevel.INFO

# Usage - concise and safe:
./app.py -n myapp -h 0.0.0.0 -p 9000 --debug --log-level debug

# Or use negative flags:
./app.py -n myapp --no-debug

# Invalid log level caught immediately:
./app.py -n myapp --log-level VERBOSE
# Error: Invalid choice: 'VERBOSE' (choose from: debug, info, warning, error)

# Mix styles as needed:
./app.py --name myapp -h 0.0.0.0 -p 9000 --debug -l debug
```

---

## Key Benefits Demonstrated

1. **Short Options**: Reduces typing, familiar to CLI users (like `git -m`, `ls -la`)
2. **Negative Flags**: Natural boolean semantics (`--no-cache` is clearer than `--cache false`)
3. **Enums**: Type-safe, validated choices with helpful error messages

All features work together seamlessly and are **fully backward compatible** with existing code.
