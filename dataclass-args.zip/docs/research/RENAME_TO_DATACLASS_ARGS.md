# Complete Rename: dataclass-config → dataclass-args

## What Was Changed

### Package Name
- PyPI package name: `dataclass-config` → `dataclass-args`
- Python module name: `dataclass_config` → `dataclass_args`
- Directory name: `dataclass_config/` → `dataclass_args/`

### Files Updated (37 core files + 31 research docs)

**Code:**
- `dataclass_config/` → `dataclass_args/` (entire directory)
- All imports in tests
- All imports in examples
- All imports in package code

**Configuration:**
- `pyproject.toml` (package name, URLs, includes, coverage config)
- All GitHub workflow files (test.yml, release.yml, docs.yml, etc.)
- `scripts/coverage_report.sh`

**Documentation:**
- README.md
- QUICKSTART.md
- CONTRIBUTING.md
- CHANGELOG.md
- docs/API.md
- docs/COVERAGE.md
- All 31 files in docs/research/

**Templates:**
- .github/ISSUE_TEMPLATE/bug_report.md
- .github/ISSUE_TEMPLATE/feature_request.md

### Cleanup
- Removed `dataclass_config.egg-info/`
- Removed old build artifacts

## Validation

✓ All 230 tests passing
✓ 94.35% coverage maintained
✓ All pre-commit hooks passing
✓ Examples working correctly
✓ No remaining references to old name

## What You Need To Do

### 1. GitHub Repository
Rename the repository on GitHub:
- Go to Settings → General → Repository name
- Change to: `dataclass-args`

### 2. PyPI Publishing Setup
Go to https://pypi.org/manage/account/publishing/ and add trusted publisher:
- **PyPI Project Name:** `dataclass-args`
- **Owner:** `bassmanitram`
- **Repository name:** `dataclass-args`
- **Workflow name:** `publish.yml`
- **Environment name:** (leave blank)

### 3. Commit & Push
```bash
git status
git add -A
git commit -m "Rename package to dataclass-args"
git push origin main
```

### 4. Create Release
After pushing:
```bash
git tag v1.0.0
git push origin v1.0.0
```

Then create a GitHub Release from the tag, which will trigger automatic PyPI publishing.

## Installation After Publishing

```bash
pip install dataclass-args

# With extras
pip install dataclass-args[yaml,toml,validation]
```

## Import Statements After Publishing

```python
from dataclass_args import build_config
from dataclass_args import cli_help, cli_short, cli_choices
```
