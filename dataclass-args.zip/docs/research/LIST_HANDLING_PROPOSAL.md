# Proposal: Change List Parameter Handling

## Problem Statement

Current list handling requires repeating the option flag for each value:

```bash
# Current - awkward and verbose
$ program --file-paths path1 --file-paths path2 --file-paths path3
```

The field name `file_paths` is plural, but each `--file-paths` flag takes only one value. This is counterintuitive and verbose.

## Proposed Solution

Allow multiple values after a single flag:

```bash
# Proposed - natural and concise
$ program --file-paths path1 path2 path3
```

This matches standard CLI conventions (git, ls, cp, etc.) and aligns better with the plural field name.

---

## Assessment

### Idea Quality: GOOD

**Pros:**
1. **More intuitive** - Plural field name naturally suggests multiple values
2. **Standard convention** - Matches how most CLI tools work
3. **Cleaner syntax** - Reduces command line verbosity
4. **Better UX** - Easier to type and read
5. **Shell-friendly** - Works naturally with shell expansion: `--files *.txt`

**Cons:**
1. **Breaking change** - Existing scripts need migration
2. **Behavior change** - Changes how lists merge with config files
3. **Edge case complexity** - Need to handle optional vs required lists differently

**Overall: Strong improvement to usability**

---

## Implementation Analysis

### Code Changes Required

#### 1. builder.py - Argument Definition (30-60 min)

**Location:** `_add_field_argument()` method, lines 217-225

**Current code:**
```python
if info["is_list"]:
    # List parameters can be specified multiple times
    help_text += " (can be specified multiple times)"
    parser.add_argument(
        *arg_names, action="append", choices=choices, help=help_text
    )
```

**Proposed change:**
```python
if info["is_list"]:
    # Determine nargs based on whether list is required or optional
    # For Optional[List[T]], use '*' to allow empty
    # For List[T], use '+' to require at least one value
    if info["is_optional"]:
        nargs_val = '*'  # Zero or more values
        help_text += " (specify multiple values)"
    else:
        nargs_val = '+'  # One or more values
        help_text += " (specify one or more values)"
    
    parser.add_argument(
        *arg_names, nargs=nargs_val, choices=choices, help=help_text
    )
```

**Complexity:** Low - straightforward argparse change

#### 2. builder.py - Value Merging (15-30 min)

**Location:** `_merge_cli_args()` method, lines 327-333

**Current code:**
```python
if info["is_list"]:
    # For lists, extend existing list or create new one
    existing = config.get(field_name, [])
    if isinstance(existing, list):
        config[field_name] = existing + cli_value
    else:
        config[field_name] = cli_value
```

**Issue:** With `action='append'`, `cli_value` is already a list of lists.
With `nargs='+'`, `cli_value` is a simple list.

**Proposed change:**
```python
if info["is_list"]:
    # CLI values replace (not extend) base config values
    # This is standard argparse behavior and more predictable
    config[field_name] = cli_value
```

**Alternative (if extending is desired):**
```python
if info["is_list"]:
    # Extend existing list with CLI values
    existing = config.get(field_name, [])
    if isinstance(existing, list):
        config[field_name] = existing + cli_value
    else:
        config[field_name] = cli_value
```

**Complexity:** Low - simpler logic actually

#### 3. Test Updates (1-2 hours)

**Files to update:**
- `tests/test_basic.py` - Line 75: Update list usage
- `tests/test_builder_advanced.py` - Any list tests
- Examples using lists (if any)

**Current test pattern:**
```python
config = build_config_from_cli(
    ComplexConfig,
    [
        "--items", "item1",
        "--items", "item2", 
        "--items", "item3",
    ],
)
assert config.items == ["item1", "item2", "item3"]
```

**New test pattern:**
```python
config = build_config_from_cli(
    ComplexConfig,
    [
        "--items", "item1", "item2", "item3",
    ],
)
assert config.items == ["item1", "item2", "item3"]
```

**Complexity:** Low - mechanical find/replace in tests

#### 4. Documentation Updates (30-60 min)

**Files to update:**
- README.md - List usage examples
- Docstrings in builder.py
- API reference sections
- CHANGELOG.md - Breaking change notice

**Complexity:** Low - update examples and add migration notes

---

## Edge Cases and Solutions

### 1. Optional Lists

**Dataclass:**
```python
items: Optional[List[str]] = None
```

**Solution:** Use `nargs='*'` to allow zero values
```bash
# All valid
$ program                          # items=None (not provided)
$ program --items                  # items=[] (empty list) 
$ program --items a b              # items=['a', 'b']
```

### 2. Required Lists

**Dataclass:**
```python
items: List[str]  # No default
```

**Solution:** Use `nargs='+'` to require at least one value
```bash
$ program --items              # Error: expected at least one value
$ program --items a            # items=['a']
$ program --items a b c        # items=['a', 'b', 'c']
```

### 3. Lists with Defaults

**Dataclass:**
```python
items: List[str] = field(default_factory=list)
```

**Current behavior:** CLI values extend default list
**Proposed behavior:** CLI values replace default list (standard argparse)

**Rationale:** Replacement is more predictable and standard

### 4. Multiple List Fields

**Dataclass:**
```python
files: List[str]
configs: List[str]
```

**Usage:**
```bash
$ program --files a.txt b.txt --configs c.json d.json
```

**Works correctly:** argparse handles this naturally

### 5. Values Starting with Dash

**Problem:** `--items -weird-file.txt` might be interpreted as flag

**Solution:** Use `--` separator
```bash
$ program --items -- -weird-file.txt regular-file.txt
```

**Standard:** This is how all CLI tools handle this

### 6. Merging with Config Files

**Config file:**
```yaml
items:
  - default1
  - default2
```

**CLI:** `--items override1 override2`

**Current behavior:** Result is `['default1', 'default2', 'override1', 'override2']`
**Proposed behavior:** Result is `['override1', 'override2']`

**Rationale:** CLI override should replace, not extend. More predictable.

**Alternative:** Add metadata flag to control this per-field if needed later

---

## Migration Guide for Users

### Breaking Change

The syntax for list parameters has changed to be more intuitive.

**Old syntax:**
```bash
$ program --items item1 --items item2 --items item3
```

**New syntax:**
```bash
$ program --items item1 item2 item3
```

### Migration Steps

1. Find all list parameter usages in scripts
2. Replace multiple flag repetitions with space-separated values
3. Test that behavior is as expected

### Example Migration

**Before:**
```bash
#!/bin/bash
python deploy.py \
  --servers server1.example.com \
  --servers server2.example.com \
  --servers server3.example.com
```

**After:**
```bash
#!/bin/bash
python deploy.py \
  --servers server1.example.com server2.example.com server3.example.com

# Or using shell expansion
python deploy.py --servers server{1,2,3}.example.com
```

---

## Implementation Effort Estimate

### Breakdown

| Task | Estimated Time | Difficulty |
|------|---------------|------------|
| Code changes in builder.py | 30-60 min | Low |
| Update _merge_cli_args logic | 15-30 min | Low |
| Update test files | 1-2 hours | Low |
| Update documentation | 30-60 min | Low |
| Testing and validation | 30 min | Low |
| **Total** | **3-4 hours** | **Low-Medium** |

### Risk Assessment

**Risk Level:** Low

- Change is localized to one module
- Argparse behavior well-documented
- Test suite will catch regressions
- No complex edge cases

---

## Recommendation

### Assessment: IMPLEMENT THIS CHANGE

**Rationale:**
1. Significant usability improvement
2. Aligns with CLI conventions
3. Reasonable implementation effort
4. Low risk due to good test coverage
5. Breaking change acceptable for pre-1.0 project

### Implementation Strategy

1. **Phase 1: Code Changes**
   - Modify `_add_field_argument()` for nargs
   - Update `_merge_cli_args()` merging logic
   - Add tests for new behavior

2. **Phase 2: Testing**
   - Update existing tests
   - Add edge case tests
   - Manual testing of examples

3. **Phase 3: Documentation**
   - Update README examples
   - Update docstrings
   - Add migration guide to CHANGELOG

4. **Phase 4: Release**
   - Bump to 0.6.0 (breaking change)
   - Document in release notes
   - Update examples in repository

### Design Decisions

**Recommended choices:**

1. **nargs behavior:**
   - Use `'+'` for required `List[T]`
   - Use `'*'` for `Optional[List[T]]`

2. **Merging behavior:**
   - CLI values **replace** base config values (not extend)
   - More predictable and standard
   - Can add per-field control later if needed

3. **Help text:**
   - Change "(can be specified multiple times)" 
   - To "(specify one or more values)" or "(specify multiple values)"

4. **Short options:**
   - Works the same: `-i val1 val2 val3`

---

## Conclusion

**Idea Quality:** 9/10 - Excellent usability improvement

**Implementation Effort:** 3-4 hours - Moderate effort

**Recommendation:** Implement in next release

This change significantly improves the developer experience and aligns the library with standard CLI conventions. The implementation is straightforward with low risk, and the test suite provides good safety coverage.
