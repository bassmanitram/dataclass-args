# Feature Implementation Proposals

## Overview

Research and implementation proposals for three new dataclass-args features:

1. **Short-form options** - Allow `-n` in addition to `--name`
2. **Negative flag options** - Allow `--no-debug` to disable boolean flags
3. **Restricted value options** - Support Enum-like restricted choices

---

## 1. Short-Form Options

### Current Behavior
Currently only long-form options are supported:
```python
@dataclass
class Config:
    name: str

# Usage: --name "value"
```

### Proposed Implementation

#### A. Annotation-based Approach (Recommended)
Add a `cli_short()` annotation to specify short option:

```python
def cli_short(short: str, **kwargs) -> Any:
    """
    Add short-form option for a CLI argument.

    Args:
        short: Single character for short option (e.g., 'n' for -n)
        **kwargs: Additional field parameters

    Example:
        @dataclass
        class Config:
            name: str = cli_short('n', cli_help("Application name"))
            verbose: bool = cli_short('v', default=False)

        # Usage: -n "MyApp" -v true
        # or: --name "MyApp" --verbose true
    """
    if len(short) != 1:
        raise ValueError(f"Short option must be single character, got: {short}")

    field_kwargs = kwargs.copy()
    metadata = field_kwargs.pop("metadata", {})
    metadata["cli_short"] = short
    field_kwargs["metadata"] = metadata
    return field(**field_kwargs)
```

#### B. Implementation in builder.py

Modify `_add_field_argument()`:

```python
def _add_field_argument(
    self, parser: argparse.ArgumentParser, field_name: str, info: Dict[str, Any]
) -> None:
    """Add CLI argument for a specific config field."""
    cli_name = info["cli_name"]

    # Get short option from metadata
    short_option = self._get_short_option(info)

    # Build argument names list
    arg_names = [cli_name]
    if short_option:
        arg_names.insert(0, f"-{short_option}")  # Short comes first: -n, --name

    # Get custom help text from annotations or use default
    custom_help = get_cli_help(info)
    help_text = custom_help if custom_help else f"{field_name}"

    if info["is_list"]:
        help_text += " (can be specified multiple times)"
        parser.add_argument(*arg_names, action="append", help=help_text)
    elif info["is_dict"]:
        parser.add_argument(
            *arg_names, type=str, help=f"{help_text} configuration file path"
        )
        # Override args might not need short form
        parser.add_argument(
            info["override_name"],
            action="append",
            help=f"{help_text} property override (format: key.path:value)",
        )
    else:
        arg_type = self._get_argument_type(info["type"])
        parser.add_argument(*arg_names, type=arg_type, help=help_text)

def _get_short_option(self, field_info: Dict[str, Any]) -> Optional[str]:
    """Get short option character from field metadata."""
    field_obj = field_info.get("field_obj")
    if field_obj and hasattr(field_obj, "metadata"):
        return field_obj.metadata.get("cli_short")
    return None
```

#### C. Add helper in annotations.py

```python
def get_cli_short(field_info: Dict[str, Any]) -> Optional[str]:
    """
    Get short option character for a CLI argument.

    Args:
        field_info: Field information dictionary from GenericConfigBuilder

    Returns:
        Short option character if available, otherwise None
    """
    field_obj = field_info.get("field_obj")
    if field_obj and hasattr(field_obj, "metadata"):
        return field_obj.metadata.get("cli_short")
    return None
```

### Usage Example

```python
from dataclass_args import build_config, cli_short, cli_help

@dataclass
class Config:
    name: str = cli_short('n', cli_help("Application name"))
    host: str = cli_short('h', default="localhost")
    port: int = cli_short('p', default=8000)
    verbose: bool = cli_short('v', default=False)

# Both work:
config = build_config(Config, ['-n', 'MyApp', '-p', '9000', '-v', 'true'])
config = build_config(Config, ['--name', 'MyApp', '--port', '9000', '--verbose', 'true'])
# Mix and match:
config = build_config(Config, ['-n', 'MyApp', '--port', '9000', '-v', 'true'])
```

---

## 2. Negative Flag Options

### Current Behavior
Boolean flags currently require explicit value:
```python
# Must do: --debug true
# Cannot do: --no-debug
```

### Proposed Implementation

#### A. Automatic Negative Flags (Recommended)

For boolean fields with `default=True`, automatically add `--no-{field}` option:

```python
def _add_field_argument(
    self, parser: argparse.ArgumentParser, field_name: str, info: Dict[str, Any]
) -> None:
    """Add CLI argument for a specific config field."""
    cli_name = info["cli_name"]
    short_option = self._get_short_option(info)

    # Special handling for boolean fields
    if info["type"] == bool:
        self._add_boolean_argument(parser, field_name, info, cli_name, short_option)
        return

    # ... rest of implementation

def _add_boolean_argument(
    self,
    parser: argparse.ArgumentParser,
    field_name: str,
    info: Dict[str, Any],
    cli_name: str,
    short_option: Optional[str]
) -> None:
    """Add boolean argument with positive and negative forms."""

    custom_help = get_cli_help(info)
    help_text = custom_help if custom_help else field_name

    default_value = info.get("default", False)

    # Build argument names
    arg_names = [cli_name]
    if short_option:
        arg_names.insert(0, f"-{short_option}")

    if default_value is False:
        # Default False: --flag enables, optional --no-flag disables
        parser.add_argument(
            *arg_names,
            action="store_true",
            dest=field_name.replace("-", "_"),
            help=f"{help_text} (default: False)"
        )
        # Optional negative form for clarity
        negative_name = f"--no-{field_name.replace('_', '-')}"
        parser.add_argument(
            negative_name,
            action="store_false",
            dest=field_name.replace("-", "_"),
            help=f"Disable {help_text}"
        )
    else:
        # Default True: --flag keeps enabled, --no-flag disables
        parser.add_argument(
            *arg_names,
            action="store_true",
            dest=field_name.replace("-", "_"),
            help=f"{help_text} (default: True)"
        )
        negative_name = f"--no-{field_name.replace('_', '-')}"
        parser.add_argument(
            negative_name,
            action="store_false",
            dest=field_name.replace("-", "_"),
            help=f"Disable {help_text}"
        )
```

#### B. Opt-in via Annotation (Alternative)

For explicit control, add `cli_flag()` annotation:

```python
def cli_flag(negative: bool = True, **kwargs) -> Any:
    """
    Mark a boolean field as a flag with optional negative form.

    Args:
        negative: Whether to support --no-{field} form (default: True)
        **kwargs: Additional field parameters

    Example:
        @dataclass
        class Config:
            debug: bool = cli_flag(default=False)  # --debug and --no-debug
            verbose: bool = cli_flag(negative=False, default=False)  # Only --verbose
    """
    field_kwargs = kwargs.copy()
    metadata = field_kwargs.pop("metadata", {})
    metadata["cli_flag"] = True
    metadata["cli_negative"] = negative
    field_kwargs["metadata"] = metadata
    return field(**field_kwargs)
```

### Usage Example

```python
@dataclass
class Config:
    debug: bool = False
    production: bool = True
    verbose: bool = cli_short('v', default=False)

# Usage:
config = build_config(Config, ['--debug'])           # debug=True
config = build_config(Config, ['--no-debug'])        # debug=False (explicit)
config = build_config(Config, ['--no-production'])   # production=False
config = build_config(Config, ['-v'])                # verbose=True
config = build_config(Config, ['--no-verbose'])      # verbose=False
```

---

## 3. Restricted Value Options (Enum-like)

### Current Behavior
No validation for restricted choices. Any string accepted.

### Proposed Implementation

#### A. Standard Enum Support (Recommended)

Leverage Python's `Enum` type with automatic integration:

```python
from enum import Enum

@dataclass
class Config:
    log_level: LogLevel

# Parser will automatically restrict to enum values
```

**Implementation in builder.py:**

```python
def _get_argument_type(self, field_type: Type) -> Callable[[str], Any]:
    """Get appropriate argparse type for field type."""
    # Check if it's an Enum
    if isinstance(field_type, type) and issubclass(field_type, Enum):
        def parse_enum(value: str) -> Enum:
            """Parse enum from string (case-insensitive)."""
            try:
                # Try direct name match
                return field_type[value.upper()]
            except KeyError:
                # Try by value
                for member in field_type:
                    if member.value.upper() == value.upper():
                        return member
                # Show valid options
                valid = ', '.join(m.name for m in field_type)
                raise argparse.ArgumentTypeError(
                    f"Invalid choice: '{value}' (choose from: {valid})"
                )
        return parse_enum

    if field_type == bool:
        return lambda x: x.lower() in ("true", "1", "yes", "on")
    elif field_type in (int, float, str):
        return field_type
    else:
        return str

def _add_field_argument(
    self, parser: argparse.ArgumentParser, field_name: str, info: Dict[str, Any]
) -> None:
    """Add CLI argument for a specific config field."""
    # ... existing code ...

    # For simple scalars
    arg_type = self._get_argument_type(info["type"])

    # Add choices for enums
    choices = None
    if isinstance(info["type"], type) and issubclass(info["type"], Enum):
        choices = [m.name.lower() for m in info["type"]]
        help_text += f" (choices: {', '.join(choices)})"

    parser.add_argument(
        *arg_names,
        type=arg_type,
        choices=choices,  # argparse will validate
        help=help_text
    )
```

#### B. Custom Choices via Annotation

For non-Enum restrictions:

```python
def cli_choices(choices: List[Any], **kwargs) -> Any:
    """
    Restrict field to specific choices.

    Args:
        choices: List of valid values
        **kwargs: Additional field parameters

    Example:
        @dataclass
        class Config:
            environment: str = cli_choices(['dev', 'staging', 'prod'])
            size: str = cli_choices(['small', 'medium', 'large'], default='medium')
    """
    field_kwargs = kwargs.copy()
    metadata = field_kwargs.pop("metadata", {})
    metadata["cli_choices"] = choices
    field_kwargs["metadata"] = metadata
    return field(**field_kwargs)
```

**Implementation:**

```python
def _get_choices(self, field_info: Dict[str, Any]) -> Optional[List[Any]]:
    """Get restricted choices from field metadata or enum type."""
    # Check for enum type
    field_type = field_info["type"]
    if isinstance(field_type, type) and issubclass(field_type, Enum):
        return [m.name.lower() for m in field_type]

    # Check for explicit choices annotation
    field_obj = field_info.get("field_obj")
    if field_obj and hasattr(field_obj, "metadata"):
        return field_obj.metadata.get("cli_choices")

    return None

def _add_field_argument(self, ...):
    # ... existing code ...

    choices = self._get_choices(info)
    if choices:
        help_text += f" (choices: {', '.join(str(c) for c in choices)})"

    parser.add_argument(
        *arg_names,
        type=arg_type,
        choices=choices,
        help=help_text
    )
```

### Usage Example

```python
from enum import Enum
from dataclass_args import build_config, cli_choices, cli_help

class LogLevel(Enum):
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"

class Environment(Enum):
    DEVELOPMENT = "dev"
    STAGING = "staging"
    PRODUCTION = "prod"

@dataclass
class Config:
    # Using standard Enum
    log_level: LogLevel = LogLevel.INFO
    environment: Environment = Environment.DEVELOPMENT

    # Using cli_choices annotation
    size: str = cli_choices(['small', 'medium', 'large'], default='medium')
    region: str = cli_choices(['us-east-1', 'us-west-2', 'eu-west-1'])

# Usage:
config = build_config(Config, [
    '--log-level', 'debug',        # Case insensitive
    '--environment', 'prod',       # Accepts name or value
    '--size', 'large',
    '--region', 'us-west-2'
])

# Invalid:
config = build_config(Config, ['--log-level', 'invalid'])  # Error with valid options
```

---

## Implementation Priority & Compatibility

### Phase 1: Enum Support (Easiest)
- Leverage existing Python `Enum` type
- Minimal code changes in `_get_argument_type()`
- Backward compatible - doesn't affect existing code
- **Files to modify:** `builder.py`
- **Estimated lines:** ~30

### Phase 2: Negative Flags (Medium)
- Modify `_add_field_argument()` for boolean handling
- Add `_add_boolean_argument()` helper
- Backward compatible - adds alternative syntax
- **Files to modify:** `builder.py`
- **Estimated lines:** ~50

### Phase 3: Short Options (Moderate)
- Add `cli_short()` annotation
- Modify `_add_field_argument()` to accept multiple names
- Add `get_cli_short()` helper
- Backward compatible - purely opt-in
- **Files to modify:** `annotations.py`, `builder.py`
- **Estimated lines:** ~60

### Phase 4: Custom Choices (Optional)
- Add `cli_choices()` annotation
- Extend enum handling to support explicit lists
- Backward compatible
- **Files to modify:** `annotations.py`, `builder.py`
- **Estimated lines:** ~40

---

## Testing Requirements

### Short Options Tests
```python
def test_short_option():
    @dataclass
    class Config:
        name: str = cli_short('n')

    config = build_config(Config, ['-n', 'test'])
    assert config.name == 'test'

    config = build_config(Config, ['--name', 'test'])
    assert config.name == 'test'

def test_short_option_conflict():
    # Should raise error if two fields use same short option
    pass
```

### Negative Flags Tests
```python
def test_negative_flag_default_false():
    @dataclass
    class Config:
        debug: bool = False

    config = build_config(Config, ['--debug'])
    assert config.debug is True

    config = build_config(Config, ['--no-debug'])
    assert config.debug is False

def test_negative_flag_default_true():
    @dataclass
    class Config:
        production: bool = True

    config = build_config(Config, [])
    assert config.production is True

    config = build_config(Config, ['--no-production'])
    assert config.production is False
```

### Enum Tests
```python
def test_enum_field():
    class Level(Enum):
        LOW = "low"
        HIGH = "high"

    @dataclass
    class Config:
        level: Level = Level.LOW

    config = build_config(Config, ['--level', 'high'])
    assert config.level == Level.HIGH

    # Case insensitive
    config = build_config(Config, ['--level', 'HIGH'])
    assert config.level == Level.HIGH

    # Invalid should raise
    with pytest.raises(SystemExit):
        build_config(Config, ['--level', 'invalid'])

def test_cli_choices():
    @dataclass
    class Config:
        size: str = cli_choices(['small', 'large'])

    config = build_config(Config, ['--size', 'small'])
    assert config.size == 'small'

    with pytest.raises(SystemExit):
        build_config(Config, ['--size', 'invalid'])
```

---

## Recommendation

**Implement in order:**

1. **Enum Support** - Highest value, lowest effort
2. **Negative Flags** - Natural UX improvement for booleans
3. **Short Options** - Nice to have, requires conflict detection
4. **Custom Choices** - Optional, Enum covers most cases

All features are backward compatible and can be implemented incrementally.
