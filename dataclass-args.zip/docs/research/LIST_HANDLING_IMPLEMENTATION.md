# List Parameter Handling - Implementation Plan

## Problem

Current behavior is awkward:
```bash
# Current - must repeat flag for each value
$ program --file-paths path1 --file-paths path2 --file-paths path3
```

The field `file_paths` is plural but each flag takes one value.

## Solution

Allow multiple values after single flag:
```bash
# Proposed - natural and concise
$ program --file-paths path1 path2 path3
```

---

## Assessment

### Idea Quality: EXCELLENT (9/10)

**Pros:**
- Intuitive - plural name with multiple values
- Standard - matches git, ls, cp, etc.
- Concise - reduces verbosity
- Shell-friendly - works with globs: `--files *.txt`

**Cons:**
- Breaking change (but only internal usage exists)

### Implementation Effort: 3-4 hours

**Risk:** Low - localized change, well-tested

---

## Implementation Details

### 1. Code Changes (45-90 minutes)

#### File: `dataclass_args/builder.py`

**Location 1:** `_add_field_argument()` method (lines 217-225)

**Current:**
```python
if info["is_list"]:
    # List parameters can be specified multiple times
    help_text += " (can be specified multiple times)"
    parser.add_argument(
        *arg_names, action="append", choices=choices, help=help_text
    )
```

**Change to:**
```python
if info["is_list"]:
    # Determine nargs based on whether list is required or optional
    if info["is_optional"]:
        nargs_val = '*'  # Zero or more values for Optional[List[T]]
        help_text += " (specify zero or more values)"
    else:
        nargs_val = '+'  # One or more values for List[T]
        help_text += " (specify one or more values)"
    
    parser.add_argument(
        *arg_names, nargs=nargs_val, choices=choices, help=help_text
    )
```

**Location 2:** `_merge_cli_args()` method (lines 327-333)

**Current:**
```python
if info["is_list"]:
    # For lists, extend existing list or create new one
    existing = config.get(field_name, [])
    if isinstance(existing, list):
        config[field_name] = existing + cli_value
    else:
        config[field_name] = cli_value
```

**Change to:**
```python
if info["is_list"]:
    # CLI values replace base config values (standard argparse behavior)
    config[field_name] = cli_value
```

**Rationale:** 
- With `action='append'`, cli_value was a list of lists
- With `nargs='+'`, cli_value is a simple list
- Replacement is more predictable than extension

---

### 2. Test Updates (1-2 hours)

#### File: `tests/test_basic.py`

**Line 75:** Update list parameter test

**Current:**
```python
config = build_config_from_cli(
    ComplexConfig,
    [
        "--host", "localhost",
        "--port", "9000",
        "--items", "item1",
        "--items", "item2",
        "--items", "item3",
        "--timeout", "30.5",
    ],
)
```

**Change to:**
```python
config = build_config_from_cli(
    ComplexConfig,
    [
        "--host", "localhost",
        "--port", "9000",
        "--items", "item1", "item2", "item3",
        "--timeout", "30.5",
    ],
)
```

#### File: `tests/test_builder_advanced.py`

**Line 437 area:** Check for any list usage and update similarly

#### Search for other occurrences:
```bash
grep -rn "\-\-items.*item" tests/
grep -rn "action.*append" tests/
```

---

### 3. Add New Tests (30 minutes)

#### New test cases to add in `tests/test_basic.py`:

```python
def test_list_single_value(self):
    """Test list parameter with single value."""
    config = build_config_from_cli(
        ComplexConfig,
        ["--host", "localhost", "--items", "single_item"],
    )
    assert config.items == ["single_item"]

def test_list_multiple_values(self):
    """Test list parameter with multiple values."""
    config = build_config_from_cli(
        ComplexConfig,
        ["--host", "localhost", "--items", "a", "b", "c", "d"],
    )
    assert config.items == ["a", "b", "c", "d"]

def test_optional_list_empty(self):
    """Test optional list with no values."""
    @dataclass
    class ConfigWithOptionalList:
        name: str
        items: Optional[List[str]] = None
    
    config = build_config_from_cli(
        ConfigWithOptionalList,
        ["--name", "test", "--items"],
    )
    assert config.items == []  # Empty list when flag provided with no values

def test_optional_list_omitted(self):
    """Test optional list when flag not provided."""
    @dataclass
    class ConfigWithOptionalList:
        name: str
        items: Optional[List[str]] = None
    
    config = build_config_from_cli(
        ConfigWithOptionalList,
        ["--name", "test"],
    )
    assert config.items is None  # None when flag not provided
```

---

### 4. Documentation Updates (30-60 minutes)

#### File: `README.md`

Find list examples and update:

**Search for:** `--items.*--items`

**Example update:**
```markdown
# Before
--allowed-hosts host1 --allowed-hosts host2

# After  
--allowed-hosts host1 host2
```

#### File: `dataclass_args/builder.py`

Update docstring examples in:
- `build_config_from_cli()` docstring
- `GenericConfigBuilder` class docstring

**Current docstring example:**
```python
# Usage:
config = build_config_from_cli(MyConfig, [
    '--name', 'test',
    '--items', 'a', '--items', 'b'
])
```

**Change to:**
```python
# Usage:
config = build_config_from_cli(MyConfig, [
    '--name', 'test',
    '--items', 'a', 'b', 'c'
])
```

---

### 5. Update Examples (if any exist)

Check `examples/` directory for any list usage:
```bash
grep -rn "List\[" examples/
grep -rn "\-\-.*\-\-" examples/  # Find repeated flags
```

Update any examples found.

---

## Edge Cases to Handle

### 1. Optional Lists

**Field:** `items: Optional[List[str]] = None`

**Behavior with `nargs='*'`:**
```bash
$ program                          # items=None (flag not provided)
$ program --items                  # items=[] (flag provided, no values)
$ program --items a b              # items=['a', 'b']
```

### 2. Required Lists

**Field:** `items: List[str]` (no default)

**Behavior with `nargs='+'`:**
```bash
$ program --items              # Error: expected at least one argument
$ program --items a            # items=['a']
$ program --items a b c        # items=['a', 'b', 'c']
```

### 3. Lists with Default Factories

**Field:** `items: List[str] = field(default_factory=list)`

**Behavior:**
- If flag not provided: uses default (empty list)
- If flag provided: replaces default

### 4. Values Starting with Dash

**Problem:** `--items -weird-file.txt` interprets `-weird-file.txt` as flag

**Solution:** Use `--` separator (standard)
```bash
$ program --items -- -weird-file.txt normal-file.txt
```

### 5. Multiple List Fields

```bash
$ program --files a.txt b.txt --configs c.json d.json
```
Works correctly - argparse handles this naturally.

---

## Testing Checklist

- [ ] Single value in list
- [ ] Multiple values in list  
- [ ] Empty optional list (`--items` with no values)
- [ ] Optional list not provided (flag omitted)
- [ ] Required list without flag (should error)
- [ ] Required list with single value
- [ ] Multiple list fields in same command
- [ ] List with choices validation
- [ ] List with short options
- [ ] Values starting with dash (using `--`)
- [ ] Shell glob expansion (manual test)
- [ ] List merging with config file (replacement behavior)

---

## Implementation Steps

1. **Backup tests** - Save current test state
   ```bash
   git stash  # Save any uncommitted changes
   git checkout -b feature/list-nargs-handling
   ```

2. **Make code changes** in `builder.py`
   - Update `_add_field_argument()`
   - Update `_merge_cli_args()`

3. **Run tests to see failures**
   ```bash
   pytest tests/test_basic.py -v
   ```

4. **Update failing tests** one by one
   - Change from `--items a --items b` to `--items a b`

5. **Add new test cases** for edge cases

6. **Update documentation**
   - README.md examples
   - Docstrings
   - Type support table (if needed)

7. **Run full test suite**
   ```bash
   pytest tests/ -v
   pytest tests/ --cov=dataclass_args
   ```

8. **Manual testing**
   ```bash
   cd examples
   # Test any examples with lists
   ```

9. **Format and lint**
   ```bash
   black dataclass_args/ tests/
   isort dataclass_args/ tests/
   flake8 dataclass_args/ tests/
   mypy dataclass_args/
   ```

10. **Commit changes**
    ```bash
    git add .
    git commit -m "Change list parameter handling to use nargs instead of append

    Lists now accept multiple values after a single flag:
    --items a b c

    Instead of repeating the flag:
    --items a --items b --items c

    This is more intuitive and matches CLI conventions.

    - Use nargs='+' for required List[T]
    - Use nargs='*' for Optional[List[T]]
    - CLI values replace (not extend) base config
    - Update all tests and documentation"
    ```

---

## Expected Outcome

### Before
```bash
$ program --files a.txt --files b.txt --files c.txt
```

### After
```bash
$ program --files a.txt b.txt c.txt

# Works with shell expansion
$ program --files *.txt

# Works with brace expansion
$ program --files file{1,2,3}.txt
```

### Help Output Before
```
--items ITEMS         Item list (can be specified multiple times)
```

### Help Output After
```
--items ITEMS [ITEMS ...]
                      Item list (specify one or more values)
```

---

## Summary

**Time Estimate:** 3-4 hours

**Breakdown:**
- Code changes: 45-90 min
- Test updates: 1-2 hours
- Documentation: 30-60 min
- Validation: 30 min

**Complexity:** Low - straightforward argparse change

**Risk:** Low - localized change with good test coverage

**Value:** High - significant UX improvement

**Recommendation:** Implement now (no public users to migrate)
