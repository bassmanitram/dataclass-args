# Positional Arguments Research & Implementation Plan

## Executive Summary

**Goal:** Add positional argument support to match argparse-dataclass feature parity.

**Status:** Fully researched, ready for implementation.

**Estimated Effort:** 1-2 weeks (including tests and docs)

---

## 1. Argparse Positional Arguments Behavior

### Basic Positional Arguments

```python
parser.add_argument('source', help='Source file')
parser.add_argument('dest', help='Destination file')
```

**Key Characteristics:**
- No `--` prefix (that's what makes them positional)
- Order matters (unlike optional arguments)
- Can be required or optional
- Must be added to parser before optional arguments are parsed
- Position in CLI determines which argument gets which value

**Usage:**
```bash
$ prog source.txt dest.txt --verbose
# source='source.txt', dest='dest.txt', verbose=True
```

---

### Positional Argument Variations

| Type | nargs | Example | Behavior |
|------|-------|---------|----------|
| **Required** | (none) | `'source'` | Must provide exactly one |
| **Optional** | `'?'` | `'output', nargs='?'` | Zero or one value |
| **Variable** | `'*'` | `'files', nargs='*'` | Zero or more values (list) |
| **At least one** | `'+'` | `'files', nargs='+'` | One or more values (list) |
| **Exact count** | `2` | `'point', nargs=2` | Exactly N values (list) |

**Examples:**

```python
# Optional positional
parser.add_argument('output', nargs='?', default='stdout')
$ prog input.txt          # output='stdout'
$ prog input.txt out.txt  # output='out.txt'

# Variable number
parser.add_argument('files', nargs='*')
$ prog a.txt b.txt c.txt  # files=['a.txt', 'b.txt', 'c.txt']
$ prog                    # files=[]

# At least one
parser.add_argument('files', nargs='+')
$ prog a.txt              # files=['a.txt']
$ prog                    # ERROR: required

# Exact count
parser.add_argument('point', nargs=2, type=float)
$ prog 1.5 2.5            # point=[1.5, 2.5]
```

---

### Important Rules

1. **Order Matters**
   - Positionals are matched by position in command line
   - `source dest` != `dest source`

2. **Must Be Added First**
   - Positional arguments must be defined before optionals in parser
   - (But can be specified anywhere in CLI command)

3. **Work with All Features**
   - `type=` for type conversion
   - `choices=` for validation
   - `help=` for documentation
   - `metavar=` for help display

4. **Can Mix with Optionals**
   ```bash
   $ prog input.txt output.txt --format json --verbose
   # Positionals: input.txt, output.txt
   # Optionals: format=json, verbose=True
   ```

---

## 2. Competitor Implementations

### argparse-dataclass (92 stars) ⭐

**Approach:** Use `field(metadata=dict(args=["name"]))` with no prefix

```python
from dataclasses import dataclass, field
from argparse_dataclass import ArgumentParser

@dataclass
class Options:
    # Positional (no -- prefix in args list)
    input: str = field(metadata=dict(args=["input"]))
    output: str = field(metadata=dict(args=["output"]))
    
    # Optional (has -- prefix)
    format: str = field(default='json', metadata=dict(args=["--format", "-f"]))

parser = ArgumentParser(Options)
opts = parser.parse_args(["in.txt", "out.txt", "-f", "yaml"])
```

**How it works:**
- If `args` list contains no `--` prefix → positional
- If `args` list starts with `--` or `-` → optional
- Simple and intuitive

---

### dataclass-cli (abandoned)

**Approach:** Use `metadata={"positional": True}`

```python
@dataclass
class Person:
    name: str = field(metadata={"positional": True})
    age: int = 30  # optional
```

**Less flexible:**
- Boolean flag only
- No control over nargs
- Basic implementation

---

## 3. Our Current Architecture

### Annotation System

We currently use:
```python
cli_short('n')       # Short option
cli_choices([...])   # Value validation
cli_help("Help")     # Custom help
cli_exclude()        # Exclude from CLI
cli_file_loadable()  # File loading
combine_annotations(...) # Compose multiple
```

All work via `field(metadata={...})`

### Builder System

Current flow:
1. `_analyze_config_fields()` - Inspect dataclass fields
2. `add_arguments()` - Add all arguments to parser
3. `_add_field_argument()` - Add single field (handles bool specially)
4. `_merge_cli_args()` - Merge parsed args into config

**Key insight:** We process fields in order (dataclass definition order is preserved)

---

## 4. Proposed Design

### Option A: Metadata-based (Like argparse-dataclass) ⭐ RECOMMENDED

**Add new annotation function:**

```python
def cli_positional(
    nargs: Union[int, str, None] = None,
    metavar: Optional[str] = None,
    **kwargs
) -> Any:
    """
    Mark a field as a positional CLI argument.
    
    Args:
        nargs: Number of arguments ('?', '*', '+', int, or None)
               None = exactly one (required)
               '?' = zero or one (optional)
               '*' = zero or more (list)
               '+' = one or more (list, required)
               int = exact count (list)
        metavar: Name for display in help text
        **kwargs: Additional field parameters (default, etc.)
    
    Examples:
        # Required positional
        source: str = cli_positional()
        
        # Optional positional
        output: str = cli_positional(nargs='?', default='stdout')
        
        # Variable number
        files: List[str] = cli_positional(nargs='*', default_factory=list)
        
        # At least one
        files: List[str] = cli_positional(nargs='+')
        
        # Combined with help
        source: str = combine_annotations(
            cli_positional(),
            cli_help("Source file path")
        )
    """
    field_kwargs = kwargs.copy()
    metadata = field_kwargs.pop("metadata", {})
    metadata["cli_positional"] = True
    if nargs is not None:
        metadata["cli_positional_nargs"] = nargs
    if metavar is not None:
        metadata["cli_positional_metavar"] = metavar
    field_kwargs["metadata"] = metadata
    return field(**field_kwargs)
```

**Usage Examples:**

```python
@dataclass
class CopyArgs:
    # Simple required positionals
    source: str = cli_positional(help="Source file")
    dest: str = cli_positional(help="Destination file")
    
    # Optional flag
    recursive: bool = cli_short('r', default=False)
    
    # Short option
    format: str = cli_short('f', default='json')

# CLI: cp.py source.txt dest.txt -r -f yaml
```

```python
@dataclass
class GitCommit:
    # Variable number of files
    files: List[str] = cli_positional(nargs='+', help="Files to commit")
    
    # Optional message
    message: str = cli_short('m', default="")

# CLI: git-commit.py file1.py file2.py -m "Add feature"
```

```python
@dataclass
class PlotPoint:
    # Exact count
    coordinates: List[float] = cli_positional(
        nargs=2, 
        metavar='X Y',
        help="X and Y coordinates"
    )
    
    # Optional label
    label: str = cli_positional(nargs='?', default='', help="Point label")
    
    # Optional flag
    show_grid: bool = cli_short('g', default=False)

# CLI: plot.py 1.5 2.5 "Point A" --show-grid
```

---

### Option B: Type-based Detection

**Automatically detect positionals by position and lack of default:**

```python
@dataclass
class Args:
    source: str          # No default → positional (first)
    dest: str            # No default → positional (second)
    format: str = 'json' # Has default → optional (--format)
```

**Problems:**
- Ambiguous: What if I want a required optional argument?
- Less explicit
- Harder to control nargs
- Breaks existing code (fields without defaults would become positional)

**Verdict:** ❌ Don't use this approach

---

### Option C: Separate Positional Class

**Create a special marker type:**

```python
from dataclass_args import Positional

@dataclass
class Args:
    source: Positional[str]
    dest: Positional[str]
    format: str = 'json'
```

**Problems:**
- Not compatible with pure dataclasses
- Complicates type checking
- Requires custom types

**Verdict:** ❌ Too invasive

---

## 5. Recommended Implementation

### ✅ Use Option A: Metadata-based Annotation

**Why:**
1. ✅ Consistent with our existing annotation system
2. ✅ Explicit and clear
3. ✅ Flexible (supports all nargs options)
4. ✅ Compatible with `combine_annotations()`
5. ✅ Similar to argparse-dataclass (familiar)
6. ✅ Pure dataclass compatible

---

## 6. Implementation Plan

### Phase 1: Core Annotation (2-3 days)

**File:** `dataclass_args/annotations.py`

Add functions:
```python
def cli_positional(nargs=None, metavar=None, **kwargs) -> Any:
    """Mark field as positional argument."""
    
def is_cli_positional(field_info: Dict[str, Any]) -> bool:
    """Check if field is positional."""
    
def get_cli_positional_nargs(field_info: Dict[str, Any]) -> Optional[Union[int, str]]:
    """Get nargs value for positional."""
    
def get_cli_positional_metavar(field_info: Dict[str, Any]) -> Optional[str]:
    """Get metavar for positional."""
```

---

### Phase 2: Builder Support (3-4 days)

**File:** `dataclass_args/builder.py`

#### Changes to `_analyze_config_fields()`:

```python
field_info = {
    # ... existing fields ...
    "is_positional": is_cli_positional(field_obj_info),
    "positional_nargs": get_cli_positional_nargs(field_obj_info),
    "positional_metavar": get_cli_positional_metavar(field_obj_info),
}
```

#### Changes to `add_arguments()`:

```python
def add_arguments(self, parser, base_config_name="config"):
    # Add base config
    parser.add_argument(f"--{base_config_name}", ...)
    
    # IMPORTANT: Add positionals first, then optionals
    # This matches argparse requirements
    
    # Add positional arguments
    for field_name, info in self._config_fields.items():
        if info.get("is_positional", False):
            self._add_positional_argument(parser, field_name, info)
    
    # Add optional arguments
    for field_name, info in self._config_fields.items():
        if not info.get("is_positional", False):
            self._add_field_argument(parser, field_name, info)
```

#### New method `_add_positional_argument()`:

```python
def _add_positional_argument(
    self, 
    parser: argparse.ArgumentParser,
    field_name: str,
    info: Dict[str, Any]
) -> None:
    """Add positional argument to parser."""
    
    # Positional arguments use the field name directly (no --)
    arg_name = field_name
    
    # Get nargs from metadata
    nargs = info.get("positional_nargs")
    
    # Get metavar from metadata
    metavar = info.get("positional_metavar")
    if not metavar:
        # Default metavar is uppercase field name
        metavar = field_name.upper()
    
    # Get help text
    help_text = get_cli_help(info) or f"{field_name}"
    
    # Get choices if specified
    choices = get_cli_choices(info)
    
    # Get type converter
    arg_type = self._get_argument_type(info["type"])
    
    # Build kwargs
    kwargs = {
        'help': help_text,
        'metavar': metavar,
    }
    
    if nargs is not None:
        kwargs['nargs'] = nargs
    
    if choices:
        kwargs['choices'] = choices
    
    # Only add type if not a list (nargs handles list conversion)
    if not (nargs in ('*', '+') or isinstance(nargs, int)):
        kwargs['type'] = arg_type
    else:
        # For list-like nargs, still need type for each element
        kwargs['type'] = arg_type
    
    # Add default if specified and nargs allows it
    if nargs in ('?', '*'):
        default = info.get('default')
        if default is not None:
            kwargs['default'] = default
    
    parser.add_argument(arg_name, **kwargs)
```

#### Changes to `_merge_cli_args()`:

```python
def _merge_cli_args(self, base_config, args):
    config = base_config.copy()
    
    for field_name, info in self._config_fields.items():
        arg_name = field_name.replace("-", "_")
        cli_value = getattr(args, arg_name, None)
        
        if cli_value is not None:
            # Handle positional vs optional the same way
            # (same merging logic applies)
            if info["is_list"] or info.get("positional_nargs") in ('*', '+') or isinstance(info.get("positional_nargs"), int):
                config[field_name] = cli_value
            elif info["is_dict"]:
                # ... dict handling ...
            else:
                # ... scalar handling ...
        
    return config
```

---

### Phase 3: Testing (2-3 days)

**File:** `tests/test_positional.py`

Test cases:
```python
def test_required_positional():
    """Test required positional argument."""
    
def test_optional_positional():
    """Test optional positional with nargs='?'."""
    
def test_variable_positional():
    """Test variable positional with nargs='*'."""
    
def test_at_least_one_positional():
    """Test at-least-one positional with nargs='+'."""
    
def test_exact_count_positional():
    """Test exact count positional with nargs=2."""
    
def test_mixed_positional_and_optional():
    """Test mixing positional and optional arguments."""
    
def test_positional_with_choices():
    """Test positional with restricted choices."""
    
def test_positional_with_help():
    """Test positional with custom help text."""
    
def test_positional_with_combine_annotations():
    """Test using combine_annotations with positional."""
    
def test_multiple_positionals_order():
    """Test that multiple positionals maintain order."""
    
def test_positional_error_handling():
    """Test error messages for missing/invalid positionals."""
```

---

### Phase 4: Documentation (1-2 days)

**Update files:**
1. `README.md` - Add positional arguments section
2. `docs/API.md` - Document `cli_positional()`
3. `examples/positional_example.py` - Create example

**README section:**

```markdown
### Positional Arguments

Add positional arguments to your CLI:

\```python
from dataclasses import dataclass
from dataclass_args import build_config, cli_positional, cli_short

@dataclass
class CopyArgs:
    source: str = cli_positional(help="Source file")
    dest: str = cli_positional(help="Destination file")
    recursive: bool = cli_short('r', default=False)

config = build_config(CopyArgs)
\```

\```bash
# Positional arguments don't need flags
$ python cp.py source.txt dest.txt -r
\```

#### Variable Number of Arguments

\```python
@dataclass
class CommitArgs:
    # One or more files (nargs='+')
    files: List[str] = cli_positional(nargs='+', help="Files to commit")
    
    # Optional message
    message: str = cli_short('m', default="")

# CLI: prog file1.py file2.py file3.py -m "Message"
\```

#### Optional Positionals

\```python
@dataclass
class ConvertArgs:
    input: str = cli_positional(help="Input file")
    output: str = cli_positional(nargs='?', default='stdout', help="Output file")

# Both valid:
# prog input.txt output.txt
# prog input.txt  # Uses default 'stdout'
\```
\```
```

---

### Phase 5: Examples (1 day)

**Create:** `examples/positional_example.py`

```python
#!/usr/bin/env python3
"""
Example demonstrating positional arguments with dataclass-args.
"""

from dataclasses import dataclass
from typing import List
from dataclass_args import build_config, cli_positional, cli_short, combine_annotations, cli_help

@dataclass
class FileProcessor:
    """Process files with optional output."""
    
    # Required positionals
    input_file: str = combine_annotations(
        cli_positional(),
        cli_help("Input file to process")
    )
    
    # Optional positional
    output_file: str = combine_annotations(
        cli_positional(nargs='?'),
        cli_help("Output file (default: stdout)"),
        default='stdout'
    )
    
    # Optional flags
    verbose: bool = cli_short('v', default=False)
    format: str = cli_short('f', default='json')

@dataclass
class MultiFile:
    """Process multiple files."""
    
    # One or more files
    files: List[str] = combine_annotations(
        cli_positional(nargs='+'),
        cli_help("Files to process")
    )
    
    # Optional flags
    recursive: bool = cli_short('r', default=False)

if __name__ == "__main__":
    print("Example 1: Single file processor")
    config1 = build_config(FileProcessor, args=['input.txt', '-v'])
    print(f"  Input: {config1.input_file}")
    print(f"  Output: {config1.output_file}")
    print(f"  Verbose: {config1.verbose}")
    
    print("\nExample 2: Multi-file processor")
    config2 = build_config(MultiFile, args=['file1.txt', 'file2.txt', 'file3.txt', '-r'])
    print(f"  Files: {config2.files}")
    print(f"  Recursive: {config2.recursive}")
```

---

## 7. Edge Cases & Considerations

### Ordering Requirements

**Dataclass field order = CLI positional order:**

```python
@dataclass
class Args:
    pos1: str = cli_positional()  # First positional
    pos2: str = cli_positional()  # Second positional
    opt1: str = 'default'         # Optional (can appear anywhere in CLI)

# CLI: prog value1 value2 --opt1 test
# pos1='value1', pos2='value2', opt1='test'
```

### Mixing with Base Config

**Question:** Should positionals work with `--config` base file?

**Answer:** Yes, but positionals override config file values

```yaml
# config.yaml
input_file: "default_input.txt"
output_file: "default_output.txt"
```

```bash
$ prog --config config.yaml new_input.txt
# input_file='new_input.txt' (positional overrides)
# output_file='default_output.txt' (from config)
```

### Validation

**Positionals with choices:**
```python
command: str = combine_annotations(
    cli_positional(),
    cli_choices(['start', 'stop', 'restart'])
)

# CLI: prog start  # OK
# CLI: prog invalid  # ERROR: invalid choice
```

### Help Display

**Positionals appear in usage line:**
```
usage: prog [-h] [--config CONFIG] SOURCE DEST [--format FORMAT]

positional arguments:
  SOURCE           Source file
  DEST             Destination file

optional arguments:
  --format FORMAT  Output format (default: json)
```

---

## 8. API Design Summary

### New Functions

```python
# Core annotation
cli_positional(nargs=None, metavar=None, **kwargs) -> Field

# Helper functions (internal)
is_cli_positional(field_info: Dict) -> bool
get_cli_positional_nargs(field_info: Dict) -> Optional[Union[int, str]]
get_cli_positional_metavar(field_info: Dict) -> Optional[str]
```

### Usage Patterns

```python
# Simple required
field: str = cli_positional()

# Optional
field: str = cli_positional(nargs='?', default='value')

# List (zero or more)
field: List[str] = cli_positional(nargs='*', default_factory=list)

# List (one or more)
field: List[str] = cli_positional(nargs='+')

# Exact count
field: List[float] = cli_positional(nargs=2, metavar='X Y')

# With help
field: str = combine_annotations(
    cli_positional(),
    cli_help("Help text")
)

# With choices
field: str = combine_annotations(
    cli_positional(),
    cli_choices(['a', 'b', 'c'])
)
```

---

## 9. Timeline Estimate

| Phase | Task | Days | Deliverable |
|-------|------|------|-------------|
| 1 | Core annotation functions | 2-3 | `cli_positional()` working |
| 2 | Builder integration | 3-4 | Can parse positionals |
| 3 | Testing | 2-3 | 20+ test cases passing |
| 4 | Documentation | 1-2 | README, API docs updated |
| 5 | Examples | 1 | Working example file |
| **Total** | | **9-13 days** | **~2 weeks** |

---

## 10. Risks & Mitigation

### Risk 1: Order Sensitivity

**Issue:** Positionals must be added to parser before optionals

**Mitigation:** 
- Separate loops in `add_arguments()`
- First loop: positionals only
- Second loop: optionals only
- Well documented in code

### Risk 2: Backward Compatibility

**Issue:** Existing code should not break

**Mitigation:**
- New feature is opt-in (requires `cli_positional()`)
- Default behavior unchanged
- All existing tests must still pass

### Risk 3: nargs Complexity

**Issue:** Many nargs options, each with different behavior

**Mitigation:**
- Comprehensive test coverage
- Clear documentation with examples
- Error messages guide users

### Risk 4: Type Confusion

**Issue:** List[str] field could mean:
- Optional argument with multiple values (`--items a b c`)
- Positional with nargs='+' (`a b c`)

**Mitigation:**
- Explicit marking required (`cli_positional(nargs='+')`)
- Clear error messages
- Examples show both cases

---

## 11. Success Criteria

**Feature is complete when:**

1. ✅ `cli_positional()` annotation works
2. ✅ All nargs variants supported ('?', '*', '+', int)
3. ✅ Positionals work with choices
4. ✅ Positionals work with help text
5. ✅ Positionals work with `combine_annotations()`
6. ✅ Positionals mix cleanly with optionals
7. ✅ Order is preserved (dataclass → CLI)
8. ✅ 20+ test cases pass
9. ✅ Documentation complete
10. ✅ Example file works
11. ✅ All existing tests still pass
12. ✅ Closes feature gap with argparse-dataclass

---

## 12. Alternatives Considered

### Alternative: Use existing List[T] syntax

**Idea:** Treat List[str] without default as positional

```python
@dataclass
class Args:
    files: List[str]  # Auto-detect as positional?
```

**Rejected because:**
- Ambiguous (could want `--files a b c`)
- Not explicit
- Breaks existing code
- Less flexible (can't control nargs)

### Alternative: Special marker in field name

**Idea:** Use naming convention like `pos_source`

**Rejected because:**
- Ugly
- Not discoverable
- Hard to type check
- Inflexible

---

## 13. Conclusion & Next Steps

### Summary

- ✅ Research complete
- ✅ Design chosen (metadata-based annotation)
- ✅ Implementation plan ready
- ✅ Timeline estimated (2 weeks)
- ✅ Risks identified and mitigated

### Recommended Next Steps

1. **Get approval** for design approach
2. **Create feature branch** (`feature/positional-arguments`)
3. **Implement Phase 1** (annotations)
4. **Implement Phase 2** (builder integration)
5. **Implement Phase 3** (tests)
6. **Implement Phases 4-5** (docs & examples)
7. **Code review & merge**
8. **Update CHANGELOG** for v1.1.0

### Benefits After Implementation

- ✅ Feature parity with argparse-dataclass
- ✅ Covers common CLI patterns (cp, mv, git, etc.)
- ✅ Maintains clean API design
- ✅ No breaking changes
- ✅ Well-tested and documented

**Ready to implement?** 🚀

---

*Research Date: October 31, 2024*  
*Estimated Completion: November 14, 2024 (2 weeks from start)*
